package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
/**
 * DatabaseHelper class.
 * <p>
 * This class is to manage the database operations.
 * <p>
 *
 * @author	Andrew Bartle </i>
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "InventoryApp.DB";

    //UserData Table Strings
    public static final String USER_TABLE_NAME = "UserDataTable";
    public static final String COLUMN_ID_0 = "id";
    public static final String COLUMN_NAME_1 = "name";
    public static final String COLUMN_PHONE_NUMBER_2 = "phone_number";
    public static final String COLUMN_EMAIL_3 = "email";
    public static final String COLUMN_PASSWORD_4 = "password";

    //ItemData Table Strings
    private static final String ITEMS_TABLE_NAME = "ItemsDataTable";
    private static final String COLUMN_ITEMS_ID_0 = "id";
    private static final String COLUMN_EMAIL_1 = "email";
    private static final String COLUMN_DESCRIPTION_2 = "description";
    private static final String COLUMN_QUANTITY_3 = "quantity";
    private static final String COLUMN_TYPE_4 = "type";


    private static final String USERS_TABLE_CREATION = "CREATE TABLE IF NOT EXISTS " +
            USER_TABLE_NAME + " (" +
            COLUMN_ID_0 + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            COLUMN_NAME_1 + " VARCHAR, " +
            COLUMN_PHONE_NUMBER_2 + " VARCHAR, " +
            COLUMN_EMAIL_3 + " VARCHAR, " +
            COLUMN_PASSWORD_4 + " VARCHAR" + ");";

    //ItemsData Table Strings
    private static final String CREATE_ITEMS_TABLE = "CREATE TABLE IF NOT EXISTS " +
            ITEMS_TABLE_NAME + " (" +
            COLUMN_ITEMS_ID_0 + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            COLUMN_EMAIL_1 + " VARCHAR, " +
            COLUMN_DESCRIPTION_2 + " VARCHAR, " +
            COLUMN_QUANTITY_3 + " VARCHAR, " +
            COLUMN_TYPE_4 + " VARCHAR" + ");";

    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(USERS_TABLE_CREATION);
        db.execSQL(CREATE_ITEMS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + ITEMS_TABLE_NAME);
        onCreate(db);
    }

    /**
     * Database operations for USER DATA
     */

    public void createUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME_1, user.getUserName());
        values.put(COLUMN_PHONE_NUMBER_2, user.getUserPhone());
        values.put(COLUMN_EMAIL_3, user.getUserEmail());
        values.put(COLUMN_PASSWORD_4, user.getUserPass());

        db.insert(USER_TABLE_NAME, null, values);
        db.close();
    }

    /**
     * Database operations for ITEMS DATA
     */
    //Add item to database
    public void createItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_EMAIL_1, item.getUserEmail());
        values.put(COLUMN_DESCRIPTION_2, item.getDesc());
        values.put(COLUMN_QUANTITY_3, item.getQty());
        values.put(COLUMN_TYPE_4, item.getType());

        db.insert(ITEMS_TABLE_NAME, null, values);
        db.close();
    }

    //Update item in database
    public int updateItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_EMAIL_1, item.getUserEmail());
        values.put(COLUMN_DESCRIPTION_2, item.getDesc());
        values.put(COLUMN_QUANTITY_3, item.getQty());
        values.put(COLUMN_TYPE_4, item.getType());

        return db.update(ITEMS_TABLE_NAME, values, COLUMN_ID_0 + " = ?", new String[] { String.valueOf(item.getId()) });
    }

    //Delete item from database
    public void deleteItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(ITEMS_TABLE_NAME, COLUMN_ID_0 + " = ?", new String[] { String.valueOf(item.getId()) });
        db.close();
    }


    //Getting All Items
    public List<Item> getAllItems() {
        List<Item> itemList = new ArrayList<>();

        //Select All Query from Items table
        String selectQuery = "SELECT * FROM " + ITEMS_TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        //Loop through all rows to add to a list
        if (cursor.moveToFirst()) {
            do {
                Item item = new Item();
                item.setId(Integer.parseInt(cursor.getString(0)));
                item.setUserEmail(cursor.getString(1));
                item.setDesc(cursor.getString(2));
                item.setQty(cursor.getString(3));
                item.setType(cursor.getString(4));

                itemList.add(item);
            } while (cursor.moveToNext());
        }

        cursor.close();

        return itemList;
    }

    public int getItemsCount() {
        String countQuery = "SELECT * FROM " + ITEMS_TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int itemsTotal = cursor.getCount();
        cursor.close();

        return itemsTotal;
    }

}
