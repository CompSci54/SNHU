package com.example.inventoryapp;

import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
/**
 * Alert dialog activity.
 * <p>
 * This class is to allow the user to enable or disable notifications sent via SMS.
 * <p>
 *
 * @author	Andrew Bartle </i>
 */
public class AlertManager {
    public static AlertDialog doubleButton(final MainActivity context){
        //Use a builder object to create a dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.alert_title)
                .setCancelable(false)
                .setMessage(R.string.alert_message)
                .setPositiveButton(R.string.alert_enable_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Enable", Toast.LENGTH_LONG).show();
                    MainActivity.AllowSendSMS();
                    dialog.cancel();
                })
                .setNegativeButton(R.string.alert_disable_button, (dialog, arg1) -> {
                    Toast.makeText(context, "SMS Alerts Disable", Toast.LENGTH_LONG).show();
                    MainActivity.DenySendSMS();
                    dialog.cancel();
                });

        //Create and return an AlertDialog object
        return builder.create();
    }
}
