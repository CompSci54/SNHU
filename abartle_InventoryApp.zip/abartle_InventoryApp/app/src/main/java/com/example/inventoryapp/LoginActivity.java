package com.example.inventoryapp;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import static com.example.inventoryapp.DatabaseHelper.USER_TABLE_NAME;
/**
 * Login Class.
 * <p>
 * This class includes the functionality to log in to the app.
 * <p>
 *
 * @author	Andrew Bartle </i>
 */
public class LoginActivity extends AppCompatActivity {
    Activity activity;
    Button loginButton, signupButton;
    EditText email, password;
    String nameHolder, phoneNumberHolder, emailHolder, passwordHolder;
    Boolean textEmpty;
    SQLiteDatabase db;
    DatabaseHelper handler;
    String tempPassword = "NOT_FOUND" ;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        activity = this;
        loginButton = findViewById(R.id.signinButton);
        email = findViewById(R.id.editTextEmailAddress);
        password = findViewById(R.id.editTextPassword);
        signupButton = findViewById(R.id.registerButton);
        handler = new DatabaseHelper(this);

        loginButton.setOnClickListener(view -> {
            //Call Login function
            LoginFunction();
        });

        //Listener to go to the Signup activity.
        signupButton.setOnClickListener(view -> {
            // Open the SignUp screen.
            Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
            startActivity(intent);
        });

    }

    public void LoginFunction() {
        String message = GetLoginInput();

        if(!textEmpty) {
            //Get SQLite database write permission
            db = handler.getWritableDatabase();

            //Create item search
            Cursor cursor = db.query(USER_TABLE_NAME, null, " " + DatabaseHelper.COLUMN_EMAIL_3 + "=?", new String[]{emailHolder}, null, null, null);

            while (cursor.moveToNext()) {
                if (cursor.isFirst()) {
                    cursor.moveToFirst();

                    //Get password and name associated with entered email to use to check login creds
                    tempPassword = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PASSWORD_4));
                    nameHolder = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_NAME_1));
                    phoneNumberHolder = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PHONE_NUMBER_2));

                    //Close cursor.
                    cursor.close();
                }
            }
            handler.close();

            //Call method to for user information
            CheckUserLoginCreds();
        } else {
            //If any of login EditText empty then display this message to the user.
            Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
        }
    }

    //Ensure text fields are not empty. If they are not, store them in holders.
    public String GetLoginInput() {
        String message = "";
        emailHolder = email.getText().toString().trim();
        passwordHolder = password.getText().toString().trim();

        if (emailHolder.isEmpty()){
            email.requestFocus();
            textEmpty = true;
            message = "User Email is not entered";
        } else if (passwordHolder.isEmpty()){
            password.requestFocus();
            textEmpty = true;
            message = "User Password is not entered";
        } else {
            textEmpty = false;
        }
        return message;
    }

    //Checking entered password from SQLite database
    public void CheckUserLoginCreds(){
        if(tempPassword.equalsIgnoreCase(passwordHolder)) {
            Toast.makeText(LoginActivity.this,"Login Successful",Toast.LENGTH_SHORT).show();

            //Sending Name to MainActivity using intent
            Bundle bundle = new Bundle();
            bundle.putString("user_name", nameHolder);
            bundle.putString("user_email", emailHolder);
            bundle.putString("user_phone", phoneNumberHolder);

            //Go to MainActivity after login success message
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);

            //Clear editText  after login successful and close database
            ClearEditTextAfterDataInsert();
        } else {
            //Display error message if credentials are not correct
            Toast.makeText(LoginActivity.this,"Incorrect Email or Password\nor User Not Registered",Toast.LENGTH_LONG).show();
        }
        tempPassword = "NOT_FOUND" ;
    }

    public void ClearEditTextAfterDataInsert() {
        email.getText().clear();
        password.getText().clear();
    }
}
