package com.example.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;


import java.util.ArrayList;
/**
 * MainActivity Class.
 * <p>
 * This class is the main class that displayed the items in the inventory, and has navigation
 * to all major functionality of the app.
 * <p>
 *
 * @author	Andrew Bartle </i>
 */
public class MainActivity extends AppCompatActivity {

    ImageButton AddItemButton, SmsButton;
    ListView ItemsListView;
    DatabaseHelper db;
    static String NameHolder, EmailHolder, PhoneNumHolder;

    AlertDialog alert = null;
    ArrayList<Item> items;
    ItemGridCreation customItemsList;
    int itemsCount;

    public static final String UserEmail = "";
    private static final int USER_PERMISSIONS_REQUEST_SEND_SMS = 0;
    private static boolean smsAuthorized = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialize buttons, textViews, and editText variables
        AddItemButton = findViewById(R.id.addItemButton);
        SmsButton = findViewById(R.id.addAlert);
        ItemsListView = findViewById(R.id.bodyListView);
        db = new DatabaseHelper(this);

        //Receive user name and user email sent by LoginActivity
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            NameHolder = bundle.getString("user_name");
            EmailHolder = bundle.getString("user_email");
            PhoneNumHolder = bundle.getString("user_phone");
        }

        items = (ArrayList<Item>) db.getAllItems();
        itemsCount = db.getItemsCount();
        if (itemsCount > 0) {
            customItemsList = new ItemGridCreation(this, items, db);
            ItemsListView.setAdapter(customItemsList);
        } else {
            Toast.makeText(this, "No Items Added to Inventory", Toast.LENGTH_LONG).show();
        }

        //Click listener to to add a new item
        AddItemButton.setOnClickListener(view -> {
            //Open new AddItemActivity
            Intent add = new Intent(this, AddItemActivity.class);
            add.putExtra(UserEmail, EmailHolder);
            startActivityForResult(add, 1);
        });

        //Click listener to enable or disable SMS alerts
        SmsButton.setOnClickListener(view -> {
            //Get sms permission for the device
            if (ContextCompat.checkSelfPermission(this,
                    android.Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        android.Manifest.permission.SEND_SMS)) {
                    Toast.makeText(this,"Device SMS Permission is Needed", Toast.LENGTH_LONG).show();
                } else {
                    ActivityCompat.requestPermissions(this,
                            new String[] {Manifest.permission.SEND_SMS},
                            USER_PERMISSIONS_REQUEST_SEND_SMS);
                }
            } else {
                Toast.makeText(this,"Device SMS Permission is Allowed", Toast.LENGTH_LONG).show();
            }
            //Open SMS Alert Dialog
            alert = AlertManager.doubleButton(this);
            alert.show();
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                itemsCount = db.getItemsCount();

                if(customItemsList == null)	{
                    customItemsList = new ItemGridCreation(this, items, db);
                    ItemsListView.setAdapter(customItemsList);
                }

                customItemsList.items = (ArrayList<Item>) db.getAllItems();
                ((BaseAdapter)ItemsListView.getAdapter()).notifyDataSetChanged();
            } else {
                Toast.makeText(this, "Action Canceled", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static void AllowSendSMS() {
        smsAuthorized = true;
    }

    public static void DenySendSMS() {
        smsAuthorized = false;
    }

    public static void SendSMSMessage(Context context) {
        String phoneNo = PhoneNumHolder;
        String smsMsg = "Some items in your inventory have reached a quantity of 0.";

        //Check AlertDialog permission
        if (smsAuthorized) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNo, null, smsMsg, null, null);
                Toast.makeText(context, "SMS Sent", Toast.LENGTH_LONG).show();
            } catch (Exception ex) {
                Toast.makeText(context, "Device Permission Denied", Toast.LENGTH_LONG).show();
                ex.printStackTrace();
            }
        } else {
            Toast.makeText(context, "App SMS Alert Disable", Toast.LENGTH_LONG).show();
        }
    }
}