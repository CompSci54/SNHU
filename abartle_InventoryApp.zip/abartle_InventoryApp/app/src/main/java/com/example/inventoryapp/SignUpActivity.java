package com.example.inventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
/**
 * SignUpActivity Class.
 * <p>
 * This class is used for a new user that need to signup to use the app.
 * <p>
 *
 * @author	Andrew Bartle </i>
 */
public class SignUpActivity extends AppCompatActivity {
    Button signupButton, cancelButton;
    EditText nameHolder, phoneNumberHolder, emailHolder, passwordHolder;
    Boolean emptyHolder;
    SQLiteDatabase db;
    DatabaseHelper handler;
    String emailFound = "Not_Found";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        nameHolder = findViewById(R.id.editUserName);
        phoneNumberHolder = findViewById(R.id.editPhoneNumer);
        emailHolder = findViewById(R.id.editEmail);
        passwordHolder = findViewById(R.id.editTextPassword);
        signupButton = findViewById(R.id.signupButton);
        cancelButton = findViewById(R.id.signupCancelBtn);
        handler = new DatabaseHelper(this);

        //Click listener to signup
        signupButton.setOnClickListener(view -> {
            String message = EnsureEditTextNotEmpty();

            if (!emptyHolder) {
                //Check if email already exists in database
                EnsureEmailDoesNotExists();
                //Clear editText fields after inserting data into database
                ClearEditTextAfterDataInsert();
            } else {
                //Display toast message if any field is empty
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        });

        //Click listener to for cancel button
        cancelButton.setOnClickListener(view -> {
            //Go back to LoginActivity after cancel button is tapped
            startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
            this.finish();
        });

    }

    public String EnsureEditTextNotEmpty() {
        //Getting values from fields and storing into string variable to then be added to database
        String message = "";
        String name = nameHolder.getText().toString().trim();
        String phone = phoneNumberHolder.getText().toString().trim();
        String email = emailHolder.getText().toString().trim();
        String pass = passwordHolder.getText().toString().trim();

        if (name.isEmpty()) {
            nameHolder.requestFocus();
            emptyHolder = true;
            message = "Enter User Name";
        } else if (phone.isEmpty()){
            phoneNumberHolder.requestFocus();
            emptyHolder = true;
            message = "Enter Phone Number";
        } else if (email.isEmpty()){
            emailHolder.requestFocus();
            emptyHolder = true;
            message = "Enter Email";
        } else if (pass.isEmpty()){
            passwordHolder.requestFocus();
            emptyHolder = true;
            message = "Enter Password";
        } else {
            emptyHolder = false;
        }
        return message;
    }

    public void EnsureEmailDoesNotExists() {
        String email = emailHolder.getText().toString().trim();
        db = handler.getWritableDatabase();

        //Create search query
        Cursor cursor = db.query(DatabaseHelper.USER_TABLE_NAME, null, " " + DatabaseHelper.COLUMN_EMAIL_3 + "=?", new String[]{email}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                //If email exists then set email result variable to email found
                emailFound = "Email_Found";
                //Close cursor.
                cursor.close();
            }
        }
        handler.close();

        //Call method to insert data into SQLite database
        InsertCredentialsIntoDB();
    }
    public void ClearEditTextAfterDataInsert(){
        nameHolder.getText().clear();
        phoneNumberHolder.getText().clear();
        emailHolder.getText().clear();
        passwordHolder.getText().clear();
    }

    public void InsertCredentialsIntoDB(){
        String name = nameHolder.getText().toString().trim();
        String phone = phoneNumberHolder.getText().toString().trim();
        String email = emailHolder.getText().toString().trim();
        String pass = passwordHolder.getText().toString().trim();

        User user = new User(name, phone, email, pass);
        handler.createUser(user);

        // Let user know the Signup was successful.
        Toast.makeText(SignUpActivity.this,"User Signed Up Successfully", Toast.LENGTH_LONG).show();

        // Go back to Login screen after signup is successful
        startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
        this.finish();
    }
}
