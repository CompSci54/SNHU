package com.example.inventoryapp;
/**
 * Item class.
 * <p>
 * This class is to create Item objects.
 * <p>
 *
 * @author	Andrew Bartle </i>
 */
public class Item {

    int id;
    String user_email;
    String desc;
    String qty;
    String type;

    public Item() {
        super();
    }

    //Constructor
    public Item(String email, String description, String quantity, String type) {
        this.user_email = email;
        this.desc = description;
        this.qty = quantity;
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserEmail() {
        return user_email;
    }

    public void setUserEmail(String user_email) {
        this.user_email = user_email;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}
