package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.atomic.AtomicReference;
/**
 * Add Item Activity.
 * <p>
 * This class is used to add new items to the database.
 * <p>
 *
 * @author Andrew Bartle </i>
 */
public class AddItemActivity extends AppCompatActivity {
    String emailHolder, descHolder, qtyHolder, unitHolder;
    EditText itemDescValue, itemQtyValue, itemUnitValue;
    Button cancelButton, addItemButton;
    Boolean emptyHolder;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Initialize UI elements
        itemDescValue = findViewById(R.id.editTextItemDescription);
        itemUnitValue = findViewById(R.id.editTextItemType);
        itemQtyValue = findViewById(R.id.editTextItemQty);
        cancelButton = findViewById(R.id.cancelItemAddButton);
        addItemButton = findViewById(R.id.addNewItemButton);
        db = new DatabaseHelper(this);

        AtomicReference<Intent> intent = new AtomicReference<>(getIntent());

        //Get user email from the MainActivity
        emailHolder = intent.get().getStringExtra(MainActivity.UserEmail);

        //Click listener for the cancel button
        cancelButton.setOnClickListener(view -> {
            //Go back to MainActivity after the Cancel button
            Intent add = new Intent();
            setResult(0, add);
            this.finish();
        });

        //Click listener to add data to the database
        addItemButton.setOnClickListener(view -> InsertItemIntoDatabase());
    }

    //Insert new item into the database
    public void InsertItemIntoDatabase() {
        String message = CheckEditTextNotEmpty();

        if (!emptyHolder) {
            String email = emailHolder;
            String desc = descHolder;
            String qty = qtyHolder;
            String unit = unitHolder;

            //Create Item object to insert into the database
            Item item = new Item(email, desc, qty, unit);
            db.createItem(item);

            //Display toast message when data is inserted into the database
            Toast.makeText(this,"Item Added Successfully", Toast.LENGTH_LONG).show();

            //Close the add item activity
            Intent add = new Intent();
            setResult(RESULT_OK, add);
            this.finish();
        } else {
            //Display toast if any of the edit boxes are empty
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    //Ensure that the edit boxes are not empty
    public String CheckEditTextNotEmpty() {
        //Get values from the edit boxes and store them in a variable
        String message = "";
        descHolder = itemDescValue.getText().toString().trim();
        unitHolder = itemUnitValue.getText().toString().trim();
        qtyHolder = itemQtyValue.getText().toString().trim();

        if (descHolder.isEmpty()) {
            itemDescValue.requestFocus();
            emptyHolder = true;
            message = "Enter Item Description";
        } else if (unitHolder.isEmpty()){
            itemUnitValue.requestFocus();
            emptyHolder = true;
            message = "Enter Item Type";
        } else {
            emptyHolder = false;
        }
        return message;
    }

}
